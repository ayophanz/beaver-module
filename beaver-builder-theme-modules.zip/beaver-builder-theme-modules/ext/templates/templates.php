<?php

define( 'FL_BUILDER_USER_TEMPLATES_DIR', FL_MODULE_THEME_DIR . 'ext/templates/' );
define( 'FL_BUILDER_USER_TEMPLATES_URL', FL_MODULE_THEME_DIR . 'ext/templates/' );

// Classes
require_once FL_BUILDER_USER_TEMPLATES_DIR . 'classes/templates.php';
require_once FL_BUILDER_USER_TEMPLATES_DIR . 'classes/templates-admin.php';