<?php
	/*Custom Post Type Setting*/
	add_action( 'init', 'client_init', 1 );
	function client_init() {
		$labels = array(
			'name'               => 'Clients',
			'singular_name'      => 'Client Page',
			'menu_name'          => 'Clients',
			'name_admin_bar'     => 'Clients',
			'add_new'            => 'Add New Client',
			'add_new_item'       => 'Add New Client',
			'new_item'           => 'New Client Page',
			'edit_item'          => 'Edit Client',
			'view_item'          => 'View Client',
			'all_items'          => 'All Clients',
			'search_items'       => 'Search Clients',
			'parent_item_colon'  => 'Parent Client:',
			'not_found'          => 'No Client found.',
			'not_found_in_trash' => 'No Client found in Trash.',
		);
		$args = array(
			'menu_icon' 		 => 'dashicons-portfolio',
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'capability_type'    => 'post',
			'has_archive'        => true, /*false - no page slug conflic*/
			'rewrite'            => array('slug' => 'all-clients'),
			'hierarchical'       => true,
			'taxonomies'         => array('client_category'),
			'menu_position'      => 21,
			'supports'           => array( 'title', 'editor', 'thumbnail'),
		);
		register_post_type( 'client', $args );
	}
	/*Custom Post Type Category and Tags*/
	add_action( 'init', 'client_category_init', 1 );
	function client_category_init() {
		$labels = array(
			'name'              => _x( 'Client Categories', 'taxonomy general name' ),
			'singular_name'     => _x( 'Client Category', 'taxonomy singular name' ),
			'search_items'      => __( 'Search Client Categories' ),
			'all_items'         => __( 'All Client Categories' ),
			'parent_item'       => __( 'Parent Client Category' ),
			'parent_item_colon' => __( 'Parent Client Category:' ),
			'edit_item'         => __( 'Edit Client Category' ),
			'update_item'       => __( 'Update Client Category' ),
			'add_new_item'      => __( 'Add New Client Category' ),
			'new_item_name'     => __( 'New Client Category Name' ),
			'menu_name'         => __( 'Client Categories' ),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'client_category' ),
		);
		register_taxonomy( 'client_category', array( 'client' ), $args );
		
		$labels = array(
			'name'              => _x( 'Client Tags', 'taxonomy general name' ),
			'singular_name'     => _x( 'Client Tag', 'taxonomy singular name' ),
			'search_items'      => __( 'Search Client Tags' ),
			'all_items'         => __( 'All Client Tags' ),
			'parent_item'       => __( 'Parent Client Tag' ),
			'parent_item_colon' => __( 'Parent Client Tag:' ),
			'edit_item'         => __( 'Edit Client Tag' ),
			'update_item'       => __( 'Update Client Tag' ),
			'add_new_item'      => __( 'Add New Client Tag' ),
			'new_item_name'     => __( 'New Client Tag Name' ),
			'menu_name'         => __( 'Client Tags' ),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'client_tag' ),
		);
		register_taxonomy( 'client_tag', array( 'client' ), $args );
	}
	if ( !is_admin()) {
		/*Add to Sitename Menu Bar*/
		add_action('admin_bar_menu', 'menu_bar_client', 1000);
		function menu_bar_client() {
			global $wp_admin_bar;
			$website = esc_url( home_url() );
			$menu_site_name = 'site-name';
			$wp_admin_bar->add_menu(array('parent' => $menu_site_name, 'id' => 'all-client', 'title' => 'Clients', 'href' => $website.'/wp-admin/edit.php?post_type=client', 'meta'  => array( 'class' => 'menu-bar-client' ),));
		}
	}

	add_action('init', 'my_theme_slug_add_post_formats_to_page', 11);
	function my_theme_slug_add_post_formats_to_page(){
		add_post_type_support( 'client', 'post-formats' );
		register_taxonomy_for_object_type( 'post_format', 'client' );
		add_theme_support( 'post-formats', array( 'aside', 'image', 'gallery', 'video', 'audio', 'link', 'quote', 'status', ) );
	}
?>