(function($) {
	$(function() {
		
	});
})(jQuery);