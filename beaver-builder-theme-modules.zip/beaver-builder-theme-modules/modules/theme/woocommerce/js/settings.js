(function($){

	FLBuilder.registerModuleHelper('woocommerce', {

		rules: {
			layout: {
				required: true
			}
		}
	});

})(jQuery);